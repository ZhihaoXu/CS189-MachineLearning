# CS 189 Homework 6

## Name: Zhihao Xu
## Student ID: 3034288950

Almost all the codes can be simply executed by clicking run in jupyter notebook. 
Here are some remarks of my program:
1. Need to package all the corresponding py files correctly in the subfolder
2. The training part may take several minutes especially choosing the hyper-parameter
3. Don't include the file minst_data.mat, the user should drag it manually to the code folder.